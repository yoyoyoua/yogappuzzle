A simple puzzle game made in Phaser framework.

To run it, just do:

```bower install```
```npm install```
```grunt serve```

